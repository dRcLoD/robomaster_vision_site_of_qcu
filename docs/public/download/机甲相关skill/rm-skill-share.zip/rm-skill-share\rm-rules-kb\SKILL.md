---
name: rm-rules-kb
description: 用户询问 RoboMaster/机甲大师（RM）比赛规则、机器人属性、制作规范、裁判系统、通信协议、能量机关、哨兵/英雄/步兵/工程/空中机器人/飞镖/雷达，或判罚、赛程、赛季差异时使用；检索本地官方规则知识库（2025/2026/2027 赛季）作答并注明赛季与文档版本号。Use when the user asks any RoboMaster (RM/机甲大师) rule question.
---

# RoboMaster 规则知识库检索

当用户提出RM规则相关问题时，使用本技能目录下的知识库检索作答。

## 知识库位置

本技能文件夹内，即 `SKILL.md` 同级的 `rm_knowledge/` 目录。

- 索引：`rm_knowledge/index.json`
- 检索指南与赛季差异：`rm_knowledge/AGENTS.md`
- 用户补充知识（最高优先级）：`rm_knowledge/notes.md`
- 赛季文档：`rm_knowledge/25/`、`rm_knowledge/26/`、`rm_knowledge/27/`

## 检索流程

1. 先读 `rm_knowledge/index.json` 了解可用赛季和文档清单
2. 读取 `rm_knowledge/AGENTS.md`（含检索技巧和赛季差异总结）和 `rm_knowledge/notes.md`（用户补充知识，优先级最高）
3. 根据问题确定赛季（默认最新赛季，用户指定则按指定赛季）和文档类型（rulebook/specification/guide/protocol/amendment）
4. 用 `grep` 工具在对应 `.txt` 文件中搜索关键词定位行号
5. 用 `read` 读取上下文后作答，引用具体的规则条款原文

## 文档类型映射

| 问题类型 | 文档 |
|---------|------|
| 比赛规则、机制、判罚、场地、机器人属性、能量机关 | rulebook（比赛规则手册） |
| 制作尺寸、重量、功率等技术规范 | specification（制作规范手册） |
| 赛程、报到流程 | guide（参赛手册） |
| 裁判系统接口、通信协议 | protocol（通信/串口协议） |
| 规则修订、新增机制 | amendment（修订文档） |

## 关键注意

- 规则手册约5000行，必须先 grep 定位再 read，禁止全文读取
- 27赛季已收录2026-08-14官方发布会亮点PPT，正式规则文档尚未发布，回答时注明信息来源与"可能调整"
- 用户补充的知识（notes.md）与PDF冲突时，以用户补充为准
- 回答需注明依据的赛季和文档版本号
