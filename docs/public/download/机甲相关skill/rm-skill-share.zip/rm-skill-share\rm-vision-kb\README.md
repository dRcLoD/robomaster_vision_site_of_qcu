# rm-vision-kb — RoboMaster 视觉知识库技能

把《An introduction to CV and RoboMaster Perception》（RoboMaster 2022/23，作者 NeoZng / neozng1@hnu.edu.cn，湖南大学 RoBoMaster 视觉组，CC-BY/MIT 许可）这份 352 页教程做成的 ZCode 检索技能。安装后，AI 助手可以直接回答 RM 视觉相关问题并注明出自教程第几页。

## 覆盖内容

装甲板识别（传统/CNN/关键点）、能量机关（大符）、反陀螺与小陀螺观测器、自瞄框架、PnP 测距与相机标定、弹道模型与轨迹预测、卡尔曼滤波 KF/EKF/UKF、目标检测（R-CNN 家族/YOLO/Anchor-Free/ViT）、OpenCV、特征匹配、相机与镜头选型、运算平台 benchmark、IMU/激光雷达、SLAM、视觉组学习路线等。

## 安装

把整个 `rm-vision-kb` 文件夹复制到技能目录之一（任选）：

- 个人全局（推荐）：`~/.zcode/skills/rm-vision-kb/`
  - Windows 即 `C:\你的用户名\.zcode\skills\rm-vision-kb\`
- 仅当前项目可用：`<项目>/.zcode/skills/rm-vision-kb/`
- 跨工具通用位置：`~/.agents/skills/rm-vision-kb/` 或 `<项目>/.agents/skills/rm-vision-kb/`

重启会话即生效。用以下方式的问题即可自动触发：

> 能量机关的旋转函数怎么拟合？/ 小陀螺观测器怎么建模？/ NUC 和 Jetson 怎么选？/ PnP 四点解算的原理？

## 依赖（可选）

- 正文检索（grep/read）无需任何依赖。
- 查看公式/图片时用到 `scripts/render_pages.py`，需要 Python 和 pymupdf：`pip install pymupdf`

## 关于原始 PDF

原始 PDF 约 75MB，**精简分享版不包含它**——文字检索、页码定位、答题都不需要 PDF。

只有当你想渲染公式/架构图的原图时，才需要把 PDF 放到 `vision_kb/` 目录下（文件名必须与下方目录说明一致）。获取途径：上游教程仓库 https://github.com/NeoZng/vision_tutorial 。PDF 缺失时 `render_pages.py` 会给出明确提示。

## 目录说明

```
rm-vision-kb/
├── SKILL.md            # 技能入口（触发描述 + 检索流程）
├── README.md           # 本文件
├── scripts/
│   └── render_pages.py # 按页渲染 PDF 为 PNG
└── vision_kb/
    ├── index.md        # 完整目录索引（264 条，全部带页码）
    ├── AGENTS.md       # 检索技巧与页码热点表
    ├── notes.md        # 用户补充知识（最高优先级，可自行填写）
    ├── 00~15_*.md      # 按章拆分的教程正文（每页带页码标记）
    ├── fulltext_backup.txt  # 全文单文件备份
    └── An.introduction...pdf # 原始 PDF（精简分享版不含，用于渲染看图/公式）
```

## 来源与致谢

- 原教程：https://github.com/NeoZng/vision_tutorial （CC-BY / MIT）
- 作者主页：https://blog.csdn.net/NeoZng 、https://space.bilibili.com/522795884
- 本技能仅做格式转换与索引，内容版权归原作者所有
