# 检索指南

## 文件结构

- `index.md` — 完整目录（264 条，全部带 PDF 页码）。缩进层级 = 章节层级，`*` 后缀 = 原文编号重复的小节
- `00_*.md` ~ `15_*.md` — 按章拆分的正文，每页以 `===== 第 N 页 =====` 开头
- `fulltext_backup.txt` — 全文单文件备份（802KB，仅当不确定关键词属于哪章时 grep 这一个文件）
- `An.introduction.to.CV.and.RoboMaster.Perception.pdf` — 原始 PDF，352 页

## 检索技巧

1. 关键词优先用原文用语：
   - 装甲板/灯条/陀螺/大符/能量机关/小地图/弹道/超前量/预测/观测器
   - 英文术语直接搜：solvePnP、Kalman、KCF、NMS、anchor、focal loss、FCOS、DETR
2. `grep -n "关键词" 文件` 得到行号 → 向上找最近的 `===== 第 N 页 =====` 得页码 → `read` 该行号附近 ±80 行
3. 一个主题常跨两章（如"PnP"在 09 章讲标定原理、12 章讲测距应用；"预测"在 06 章讲方法、13 章讲反陀螺应用），答不全就换章再查
4. 正文提取自 LaTeX 导出的 PDF：中文完好，但**图片、公式、表格内容会缺失或乱序**；段落中夹带的小段英文公式（如 `0.785sin(1.884t)+1.305`）是可信的

## 渲染 PDF 页面（看图/公式）

```bash
python ../scripts/render_pages.py 116        # 单页
python ../scripts/render_pages.py 156 158    # 页码范围
```

输出 PNG 到系统临时目录并打印路径，用 `read` 工具查看。依赖 `pymupdf`（缺失时 `pip install pymupdf`）。

## 已知 PDF 页码热点

| 主题 | 页码 |
|------|------|
| YOLO 一代原理 | 110-113 |
| Focal Loss | 116-118 |
| OHEM | 120-122 |
| IOU loss family (GIoU/DIoU/CIoU) | 123-125 |
| GFL/DFL | 126-127 |
| FPN/PAN/Bi-FPN | 128-130 |
| DETR/Deformable DETR | 149-153 |
| 卡尔曼滤波 KF/EKF/UKF | 156-159 |
| IMM 交互多模型 | 166-168 |
| 装甲板识别(章首) | 269 |
| 能量机关(章首) | 296 |
| PnP 解算 | 309-310 |
| 弹道模型 | 318-319 |
| 反陀螺 | 320-325 |
| 自瞄算法框架 | 326-329 |
