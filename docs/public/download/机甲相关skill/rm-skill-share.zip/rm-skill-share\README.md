# RoboMaster 技能包 · 安装说明

这个包里有两个 RoboMaster（机甲大师）相关技能，解压后把两个文件夹放进 ZCode 的技能目录就能用。

| 技能 | 内容 | 大小 |
|------|------|------|
| `rm-rules-kb` | RM 官方规则知识库：2025/2026/2027 赛季的比赛规则手册、制作规范、参赛手册、裁判系统通信协议（已提取为纯文本） | 约 1 MB |
| `rm-vision-kb` | RM 视觉知识库：352 页《An introduction to CV and RoboMaster Perception》教程，按章拆分并带 PDF 页码标记 | 约 2 MB |

两个技能都不需要安装 Python、不需要联网、不需要填 API Key，检索靠 grep + read 完成。

---

## 安装（一步）

把 `rm-rules-kb` 和 `rm-vision-kb` 两个文件夹整个复制到：

```
C:\你的用户名\.zcode\skills\
```

复制完的目录结构应该长这样（注意 `SKILL.md` 必须在技能文件夹的**根目录**）：

```
C:\你的用户名\.zcode\skills\
├── rm-rules-kb\
│   ├── SKILL.md          ← 必须在这层
│   └── rm_knowledge\
└── rm-vision-kb\
    ├── SKILL.md          ← 必须在这层
    ├── scripts\
    └── vision_kb\
```

**然后新开一个会话**（或新起一轮对话）即生效。技能是启动时扫描加载的，当前已打开的会话不会热加载。

### 其他可选的安装位置

| 作用范围 | 路径 |
|---------|------|
| 个人全局（推荐） | `~/.zcode/skills/<技能名>/`，Windows 即 `C:\你的用户名\.zcode\skills\<技能名>\` |
| 只在某个项目里可用 | `<项目>/.zcode/skills/<技能名>/`（可以用 git 提交，队友拉下来就有） |
| 跨工具通用（Claude Code、Cursor 等也读） | `~/.agents/skills/<技能名>/` 或 `<项目>/.agents/skills/<技能名>/` |

---

## 怎么确认装上了

新开会话后随便问一句，比如：

- 规则："26 赛季哨兵机器人的姿态系统是什么？"
- 视觉："能量机关的旋转函数怎么拟合？"

正常表现是回答里会带来源标注，例如规则问题注明"2026 赛季规则手册 V2.1.0"，视觉问题注明"教程第 156 页"。如果 AI 说不知道或者回答得很泛，基本就是没加载成功，对照下面第三节排查。

---

## 三个容易踩的坑

**1. 同名技能会被静默遮蔽。** 如果你之前已经装过同名的技能，新拷进去的这份**不会生效**——需要先把旧的那份删掉。优先级是：用户级 `~/.zcode/skills` > 项目级 `<项目>/.zcode/skills` > 插件里的技能，同名的只有优先级最高的那个会被加载，其余不报错也不提示。

**2. `SKILL.md` 必须在该技能文件夹的根目录，且文件名大小写完全一致。** 如果你的解压工具多套了一层目录（例如解压后是 `rm-vision-kb/rm-vision-kb/SKILL.md`），把它挪上来一层。文件夹本身叫什么名字无所谓，技能名取自 `SKILL.md` 里的 `name` 字段。

**3. 技能描述（description）超过 1024 字符会被整个丢弃。** 如果你想改 `SKILL.md` 里的 description 来定制触发效果，注意别让它太长；另外模型能看到的部分大约只有前 250 个字符，所以关键词要往前放。

---

## 关于 rm-vision-kb 缺失的原始 PDF

教程原始 PDF 约 75 MB，**这个包里没有附带**（否则压缩包会大到不好传）。正文检索、页码定位、回答问题都不需要它，所以不影响日常使用。

只有当你需要看公式推导、架构图的**原图**时（正文是从 PDF 提取的文本，公式是图片、提取不到），才需要这个 PDF：

1. 从上游教程仓库 <https://github.com/NeoZng/vision_tutorial> 获取 PDF；
2. 放到 `rm-vision-kb\vision_kb\` 目录下，文件名保持为 `An.introduction.to.CV.and.RoboMaster.Perception.pdf`；
3. 之后用 `python rm-vision-kb/scripts/render_pages.py <起始页> [结束页]` 把对应页渲染成 PNG 来看。这一步需要 Python 加 `pip install pymupdf`。

如果 PDF 不在，渲染脚本会直接告诉你去哪儿下载，不会静默失败。

---

## 自己补充知识

两个技能都留了 `notes.md` 用来放官方文档之外的经验（比如你们队自己的测试数据、踩坑记录）：

- 规则：`rm-rules-kb\rm_knowledge\notes.md`
- 视觉：`rm-vision-kb\vision_kb\notes.md`

`notes.md` 的优先级高于原始文档，AI 检索时会优先采用。共享安装的话注意——这是每个人本地的文件，不会互相同步。

---

## 版权说明

- `rm-rules-kb`：内容来自 RoboMaster 官方发布的规则文档，仅做格式转换与索引；官方发布渠道 <https://bbs.robomaster.com/wiki/20204847>。
- `rm-vision-kb`：原教程《An introduction to CV and RoboMaster Perception》作者 NeoZng（湖南大学 RoboMaster 视觉组），CC-BY / MIT 许可，原文仓库 <https://github.com/NeoZng/vision_tutorial>，作者主页 <https://blog.csdn.net/NeoZng>。本技能只做格式转换与索引，版权归原作者。

**请勿把这两个技能包用于商业用途或大规模公开分发时去掉上面的署名。**
