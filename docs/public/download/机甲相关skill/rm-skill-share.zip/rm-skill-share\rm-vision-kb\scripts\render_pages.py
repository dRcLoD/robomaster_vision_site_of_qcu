"""Render pages of the bundled RM vision tutorial PDF to PNG for visual reading.

Usage:
    python render_pages.py <start_page> [end_page]

Pages are 1-based (match the `===== 第 N 页 =====` markers and index.md).
Prints the PNG paths to stdout. Requires pymupdf (pip install pymupdf).
The PDF is optional: text retrieval works without it, and this script prints
download instructions when the file is missing.
"""
import sys
import tempfile
from pathlib import Path

PDF = Path(__file__).resolve().parent.parent / "vision_kb" / "An.introduction.to.CV.and.RoboMaster.Perception.pdf"


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit("usage: python render_pages.py <start_page> [end_page]")
    start = int(sys.argv[1])
    end = int(sys.argv[2]) if len(sys.argv) > 2 else start
    if start < 1 or end < start:
        sys.exit("invalid page range")

    try:
        import pymupdf
    except ImportError:
        sys.exit("pymupdf not installed: run `pip install pymupdf`")

    if not PDF.exists():
        sys.exit(
            f"PDF not found at {PDF}\n"
            "The tutorial PDF is not bundled with this copy of the skill. Text retrieval still works "
            "without it; to render figures/formulas, download the tutorial from "
            "https://github.com/NeoZng/vision_tutorial and place the PDF at that path."
        )

    out_dir = Path(tempfile.gettempdir()) / "rm_vision_kb_pages"
    out_dir.mkdir(exist_ok=True)

    doc = pymupdf.open(PDF)
    end = min(end, len(doc))
    for pno in range(start, end + 1):
        pix = doc[pno - 1].get_pixmap(dpi=140)
        out = out_dir / f"page_{pno:03d}.png"
        pix.save(out)
        print(out)


if __name__ == "__main__":
    main()
