# RoboMaster 规则知识库技能包 (rm-rules-kb)

基于 RoboMaster 官方规则文档构建的开源技能包，让 AI 助手在任意会话中自动检索 RM 规则并回答专业问题。

## 包含内容

```
rm-rules-kb/
├── SKILL.md              # 技能定义（自动加载）
└── rm_knowledge/         # 知识库本体
    ├── index.json        # 文档索引
    ├── AGENTS.md         # AI检索引擎指南 + 赛季差异总结
    ├── notes.md          # 用户补充知识（社区经验）
    ├── import.py         # 导入新赛季文档的脚本（仅维护者使用）
    ├── README.md
    ├── 25/               # 2025赛季（5份文档）
    ├── 26/               # 2026赛季（4份文档）
    └── 27/               # 2027赛季（官方发布会亮点，2026-08-14）
```

## 安装

**无任何运行时依赖**——不需要 Python、不需要联网，知识库是已提取好的纯文本，检索靠 grep/read 完成。

**方法一：直接克隆到技能目录（推荐）**

```bash
# Linux/macOS
git clone https://github.com/striken-delta/rm-rules-kb ~/.zcode/skills/rm-rules-kb

# Windows
git clone https://github.com/striken-delta/rm-rules-kb C:\Users\<你的用户名>\.zcode\skills\rm-rules-kb
```

**方法二：手动下载解压**

解压后确保 `SKILL.md` 和 `rm_knowledge/` 直接位于技能目录下，把该目录放到以下任一位置：

| 作用范围 | 路径 |
|---------|------|
| 个人全局（推荐） | `~/.zcode/skills/rm-rules-kb/`，Windows 即 `C:\你的用户名\.zcode\skills\rm-rules-kb\` |
| 仅当前项目可用 | `<项目>/.zcode/skills/rm-rules-kb/`（随仓库提交，队友一起用） |
| 跨工具通用（Claude/Cursor 等） | `~/.agents/skills/rm-rules-kb/` 或 `<项目>/.agents/skills/rm-rules-kb/` |

**新开一个会话（或新起一轮对话）即生效**，不需要其他注册步骤。之后在任何会话提问 RM 规则问题即可自动触发。

## 使用

安装后直接提问，例如：

- "26赛季哨兵机器人的姿态系统是什么？"
- "英雄机器人在部署模式下弹速上限是多少？"
- "25和26赛季哨兵有什么区别？"

AI 会自动检索知识库并标注信息来源（赛季 + 文档版本号）。

## 更新知识库（仅维护者）

### 新赛季正式规则发布后

1. 把该赛季的 PDF 放到某个本地目录，例如 `<PDF目录>/27/`
2. 运行导入脚本（需要 Python 3 + `pip install pymupdf`）：
   ```bash
   python rm_knowledge/import.py 27 --src <PDF目录>
   ```
   也可用环境变量指定 PDF 根目录：`RM_PDF_SOURCE=<PDF目录> python rm_knowledge/import.py 27`
3. 提交并推送更新

### 补充经验性知识

直接编辑 `rm_knowledge/notes.md`，按格式追加即可（AI 会优先采用）。

## 各赛季文档版本

| 赛季 | 文档 | 版本 | 日期 |
|------|------|------|------|
| 25 | 比赛规则手册 | V2.1.0 | 2025-08-02 |
| 25 | 制作规范手册 | V2.0.0 | 2025-06-20 |
| 25 | 全国总决赛参赛手册 | V2.0.0 | 2025-07-04 |
| 25 | 裁判系统串口协议附录 | V1.9.0 | 2025-07-03 |
| 25 | 规则修订补充 | - | 2024 |
| 26 | 比赛规则手册 | V2.1.0 | 2026-07-16 |
| 26 | 制作规范手册 | V2.0.0 | 2026-06-26 |
| 26 | 全国总决赛参赛手册 | V2.1.0 | 2026-07-16 |
| 26 | 通信协议 | V2.0.0 | 2026-06-26 |
| 27 | 规则亮点发布会（官方） | 亮点版 | 2026-08-14 |

## 维护

- 知识库文本由 PyMuPDF 从官方 PDF 逐页提取，已校验与原文逐字一致
- 官方规则发布渠道：https://bbs.robomaster.com/wiki/20204847
