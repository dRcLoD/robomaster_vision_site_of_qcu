"""
RoboMaster 知识库导入脚本（维护者专用）

仅在你需要把新赛季的官方 PDF 收录进知识库时才运行；技能使用者不需要这个脚本。

用法: python import.py [赛季号...] [--src <PDF根目录>]
  例: python import.py 27 --src D:/rm_rules/doc
  例: python import.py --src /home/me/rules/doc        # 扫描该目录下所有数字赛季号
  例: python import.py 26 27 --src ./doc               # 只导入指定赛季

PDF 根目录也可用环境变量 RM_PDF_SOURCE 指定，命令行 --src 优先。

工作流程:
  1. 从 <PDF根目录>/<赛季号>/ 读取 PDF
  2. 提取文本到 rm_knowledge/<赛季号>/
  3. 更新 index.json

前置条件: Python 3 + PyMuPDF（pip install pymupdf）
"""

import fitz
import os
import sys
import json
import datetime

DEFAULT_SOURCE = os.environ.get("RM_PDF_SOURCE", "")
KB_DIR = os.path.dirname(os.path.abspath(__file__))
INDEX_PATH = os.path.join(KB_DIR, "index.json")

DOC_TYPES = {
    "rulebook": ["比赛规则手册", "对抗赛比赛规则"],
    "specification": ["制作规范手册", "机器人制作规范"],
    "guide": ["参赛手册", "总决赛参赛"],
    "protocol": ["通信协议", "串口协议", "协议附录"],
}

def classify_doc(filename):
    """根据文件名分类文档类型"""
    for dtype, keywords in DOC_TYPES.items():
        for kw in keywords:
            if kw in filename:
                return dtype
    return "amendment"

def infer_season_info(season_dir):
    """推断赛季信息"""
    year = 2000 + int(season_dir)
    return {
        "year": year,
        "label": f"{year}赛季"
    }

def extract_pdf(pdf_path, txt_path):
    """提取PDF文本"""
    if os.path.exists(txt_path) and os.path.getsize(txt_path) > 0:
        return True, "skipped"

    try:
        doc = fitz.open(pdf_path)
        page_count = doc.page_count
        page_texts = []
        for i in range(page_count):
            try:
                text = doc[i].get_text()
                if text.strip():
                    page_texts.append((i + 1, text))
            except Exception:
                pass
        doc.close()

        if page_texts:
            with open(txt_path, "w", encoding="utf-8") as f:
                for pn, pt in page_texts:
                    f.write(f"\n=== Page {pn} ===\n")
                    f.write(pt)
            return True, f"{page_count}页, {os.path.getsize(txt_path)//1024}KB"
        else:
            return False, "无文本内容"
    except Exception as e:
        return False, str(e)

def update_index(season, documents):
    """更新 index.json"""
    index = {}
    if os.path.exists(INDEX_PATH):
        with open(INDEX_PATH, "r", encoding="utf-8") as f:
            index = json.load(f)

    info = infer_season_info(season)

    if season not in index.get("seasons", {}):
        if "seasons" not in index:
            index["seasons"] = {}
        index["seasons"][season] = {
            "year": info["year"],
            "label": info["label"],
            "documents": []
        }

    existing_files = {d["file"] for d in index["seasons"][season]["documents"]}
    for doc in documents:
        if doc["file"] not in existing_files:
            index["seasons"][season]["documents"].append(doc)

    index["updated"] = datetime.date.today().isoformat()

    with open(INDEX_PATH, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)

    return index

def import_season(season, pdf_root):
    """导入一个赛季的文档"""
    print(f"\n{'='*60}")
    print(f"导入赛季: {season}")

    pdf_dir = os.path.join(pdf_root, season)
    if not os.path.isdir(pdf_dir):
        print(f"  错误: 目录不存在 {pdf_dir}")
        return False

    out_dir = os.path.join(KB_DIR, season)
    os.makedirs(out_dir, exist_ok=True)

    documents = []
    for fname in sorted(os.listdir(pdf_dir)):
        if not fname.endswith(".pdf") or fname.startswith("."):
            continue

        pdf_src = os.path.join(pdf_dir, fname)
        txt_name = os.path.splitext(fname)[0] + ".txt"
        txt_dst = os.path.join(out_dir, txt_name)

        print(f"  处理: {fname}")
        success, info = extract_pdf(pdf_src, txt_dst)
        if success:
            print(f"    结果: {info}")
            doc_entry = {
                "file": txt_name,
                "pdf": fname,
                "type": classify_doc(fname),
                "name": txt_name.replace(".txt", ""),
                "name_en": "",
                "version": "N/A",
                "date": "",
                "scope": "",
                "description": ""
            }
            documents.append(doc_entry)
        else:
            print(f"    错误: {info}")

    if documents:
        update_index(season, documents)

    print(f"  完成: 导入 {len(documents)} 个文档")
    return True

def main():
    args = sys.argv[1:]
    pdf_root = DEFAULT_SOURCE

    if "--src" in args:
        i = args.index("--src")
        if i + 1 >= len(args):
            print("错误: --src 后面需要跟一个 PDF 根目录")
            sys.exit(1)
        pdf_root = args[i + 1]
        args = args[:i] + args[i + 2:]

    if not pdf_root:
        print("错误: 未指定 PDF 根目录，请用 --src <目录> 或设置环境变量 RM_PDF_SOURCE")
        print("用法: python import.py [赛季号...] --src <PDF根目录>")
        sys.exit(1)

    pdf_root = os.path.abspath(os.path.expanduser(pdf_root))
    if not os.path.isdir(pdf_root):
        print(f"错误: PDF 根目录不存在 {pdf_root}")
        sys.exit(1)

    if args:
        seasons = args
    else:
        seasons = sorted(d for d in os.listdir(pdf_root)
                         if os.path.isdir(os.path.join(pdf_root, d)) and d.isdigit())

    if not seasons:
        print(f"错误: 在 {pdf_root} 下没找到任何以赛季号命名的子目录")
        sys.exit(1)

    print(f"PDF 根目录: {pdf_root}")
    for season in seasons:
        import_season(season, pdf_root)

    print(f"\n知识库路径: {KB_DIR}")
    print(f"索引文件: {INDEX_PATH}")
    print("导入完成.")

if __name__ == "__main__":
    main()
